#include "main.h"
#include "d_except.h"
#include "d_matrix.h"
#include "dictionary.h"
#include "fstream"
#include "grid.h"
#include "iostream"
#include <string>

using namespace std;

int main()
{
  search();
  return 0;
}
